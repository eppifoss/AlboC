#AlboC
=====
INF2100-Project Assignment. Creating a compiler for AlboC.

>Del 2.0.

##Compilation
To compile the program run the command :
````
ant jar

````
To clean run:
````
ant clean
````

## USAGE
````
java -jar <AlboC.jar> [-c] [-log{P|I|S|B|T}] [-test{scanner|parser}] <filename.alboc>
````

#AlboC
=====
INF2100-Project Assignment. Creating a compiler for AlboC.

>Del 1.0.

PROBLEM :
I am having problem with the Syntax.java file in the Del 1 part of the program. 



##Compilation
To compile the program run the command :
````
ant jar
````

## USAGE
````
java -jar <AlboC.jar> [-c] [-log{P|I|S|B|T}] [-test{scanner|parser}] <filename.alboc>
````

#AlboC
=====
INF2100-Project Assignment. Creating a compiler for AlboC.

>Version 1.0.

##Compilation
To compile the program run the command :
````
ant jar
````

## USAGE
````
java -jar <AlboC.jar> -logS -testscanner <filename.alboc>
````
